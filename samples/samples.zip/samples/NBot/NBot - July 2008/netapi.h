#ifndef __NETAPI_H__
#define __NETAPI_H__

/*************
** Function **
*************/
void netapi(ExploitInfo_s* pExploitInfo);

#endif // __NETAPI_H__