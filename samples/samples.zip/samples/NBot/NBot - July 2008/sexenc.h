void derapestrings(int authsize, int serversize);
