
#ifndef __WORMRIDE_H__
#define __WORMRIDE_H__

void	TFTPDHandler(LPVOID dwParam);
void	FtpdHandler();

#endif // __WORMRIDE_H__