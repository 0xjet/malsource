#ifndef _SYNC_SCAN_H_
#define _SYNC_SCAN_H_

void scan_init(void);
void scan_main(void);
void scan_freeze(int do_freeze);

#endif
