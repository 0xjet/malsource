#include <windows.h>

PVOID HookApi( DWORD DllNum, DWORD FuncHash, DWORD ReplacementFunc );
PVOID HookApi2( DWORD Dll, DWORD FuncVA, DWORD ReplacementFunc );
